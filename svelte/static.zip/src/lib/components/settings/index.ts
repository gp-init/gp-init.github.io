import CurrentUserForm from "./CurrentUserForm.svelte";
import ResetPasswordForm from "./ResetPasswordForm.svelte";

export {
    CurrentUserForm, ResetPasswordForm
}