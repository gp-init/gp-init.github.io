import en from './i18n/en/index.js';
import zh from './i18n/zh/index.js';

export { en, zh }
export * from './components/index.js';
