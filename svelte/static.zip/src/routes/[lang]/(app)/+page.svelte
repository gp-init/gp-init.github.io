<script lang="ts">
    import DevMenu from '~/lib/components/menu/DevMenu.svelte';
</script>

<DevMenu />
