@Package
package {{=it.packageName}};

import io.graphoenix.spi.annotation.Package;